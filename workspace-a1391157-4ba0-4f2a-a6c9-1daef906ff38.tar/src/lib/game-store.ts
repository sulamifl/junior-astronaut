"use client";

import { create } from "zustand";

/**
 * Game state for "Mars Base Commander — First Night".
 *
 * Key NASA integrations driving real gameplay (not just links):
 *  - DONKI: storm intensity (0..100) derived from REAL CME speed / flare class.
 *    Drives a countdown timer and radiation risk in the storm minigame.
 *  - RAD: Curiosity surface reference (~0.67 mSv/day) feeds a live radiation meter
 *    that reacts to the player's shelter decision.
 *  - OSDR: plant-growth minigame references real Arabidopsis/gravimetry experiments.
 *  - NASA-STD-3001: water-shielding recommendation (10 g/cm²) sets the shelter bonus.
 */

export type Phase =
  | "intro"
  | "evening"
  | "sunset-wait"
  | "plan-check"
  | "storm-decision"
  | "night"
  | "dawn"
  | "quiz"
  | "complete";

export type TimeOfDay = "Evening" | "Sunset" | "Night" | "Dawn";
export type RobotStatus = "uncharged" | "charged" | "charge-in-morning";
export type BaseStatus = "disconnected" | "ready" | "low-power";
export type Modal = null | "battery" | "robot" | "solar" | "storm" | "plan" | "science" | "greenhouse";

export type StormEventData = {
  id: string;
  kind: "CME" | "FLR" | "SEP";
  startTime: string;
  classType?: string;
  speedKmS?: number;
  sourceLocation?: string;
  note?: string;
  isReal: boolean;
  sourceUrl: string;
  source: string;
  intensity: number; // 0..100 from real NASA data
  hoursToImpact?: number;
  summary: string;
};

export type StormChoice = "none" | "shelter" | "ignore";
export type QuizAnswer = "battery" | "panels" | "antenna" | null;

export type TaskId =
  | "connect-battery"
  | "plan-rover"
  | "top-up"
  | "check-plan"
  | "survive-night"
  | "handle-storm"
  | "grow-plants"
  | "complete";

export type TaskState = "pending" | "active" | "done" | "skipped";
export type MissionTask = { id: TaskId; label: string; hint: string; state: TaskState };

export type Badge = "first-night" | "shelter-pro" | "green-thumb" | "speed-runner" | "nasa-scientist";

export interface GameState {
  // resources
  battery: number;
  batteryMax: number;
  water: number;
  air: number;
  crew: number;
  radiationLevel: number; // mSv/day, Curiosity RAD reference = 0.67

  // planning
  baseConnected: boolean;
  eveningRefillUsed: boolean;
  robotStatus: RobotStatus;
  baseStatus: BaseStatus;

  // night
  nightStage: number;
  nightPaused: boolean;
  nightEnergyUsed: number;

  // storm (NASA-integrated)
  stormEvent: StormEventData | null;
  stormChoice: StormChoice;
  stormResolved: boolean;
  stormCountdown: number; // seconds to impact (UI timer)
  stormShieldStrength: number; // 0..100 water shielding built by player

  // greenhouse (OSDR-integrated plant growth minigame)
  plantGrowth: number; // 0..100
  plantWatered: boolean;
  plantLightOn: boolean;

  // flow
  phase: Phase;
  timeOfDay: TimeOfDay;
  modal: Modal;
  assistantText: string;
  tasks: MissionTask[];
  activeTaskId: TaskId | null;

  // quiz + score
  quizAnswer: QuizAnswer;
  quizRetries: number;
  quizDone: boolean;
  score: number;
  badges: Badge[];

  // provenance
  donkiSource: string;
  donkiMessage: string;

  // actions
  setPhase: (p: Phase) => void;
  setTimeOfDay: (t: TimeOfDay) => void;
  openModal: (m: Exclude<Modal, null>) => void;
  closeModal: () => void;
  setAssistant: (t: string) => void;
  setBattery: (n: number) => void;
  connectBase: () => void;
  chargeRobotNow: () => void;
  chargeRobotMorning: () => void;
  waitSunset: () => void;
  startPlanCheck: () => void;
  beginNight: () => void;
  advanceNight: () => void;
  toggleNightPause: () => void;
  setStormEvent: (e: StormEventData) => void;
  tickStorm: () => void;
  buildShield: (amount: number) => void;
  resolveStorm: (choice: StormChoice) => void;
  waterPlant: () => void;
  togglePlantLight: () => void;
  growPlantTick: () => void;
  submitQuiz: (a: Exclude<QuizAnswer, null>) => void;
  restart: () => void;
  initFromDonki: (payload: { source: string; message: string; events: StormEventData[] }) => void;
}

const INITIAL_TASKS: MissionTask[] = [
  {
    id: "connect-battery",
    label: "Connect battery to base",
    hint: "Tap the battery, then connect it so the base can draw power at night.",
    state: "active",
  },
  {
    id: "plan-rover",
    label: "Plan rover charging",
    hint: "Tap the rover and choose: charge now or in the morning.",
    state: "pending",
  },
  {
    id: "top-up",
    label: "Top up at sunset",
    hint: "You charged the rover from the battery. Tap the solar panels to refill before night.",
    state: "pending",
  },
  {
    id: "check-plan",
    label: "Check your plan",
    hint: "Review the checklist, then start the night.",
    state: "pending",
  },
  {
    id: "survive-night",
    label: "Survive the night",
    hint: "Watch the battery power the base through 4 night stages.",
    state: "pending",
  },
  {
    id: "handle-storm",
    label: "Handle the solar storm",
    hint: "A real NASA event! Build water shielding and protect the crew.",
    state: "pending",
  },
  {
    id: "grow-plants",
    label: "Grow plants in the greenhouse",
    hint: "Tap the greenhouse and grow plants like NASA experiments on the ISS.",
    state: "pending",
  },
  {
    id: "complete",
    label: "Review what you learned",
    hint: "Answer the final question to finish the mission.",
    state: "pending",
  },
];

const INITIAL = {
  battery: 4,
  batteryMax: 6,
  water: 100,
  air: 100,
  crew: 4,
  radiationLevel: 0.67,
  baseConnected: false,
  eveningRefillUsed: false,
  robotStatus: "uncharged" as RobotStatus,
  baseStatus: "disconnected" as BaseStatus,
  nightStage: 0,
  nightPaused: false,
  nightEnergyUsed: 0,
  stormEvent: null as StormEventData | null,
  stormChoice: "none" as StormChoice,
  stormResolved: false,
  stormCountdown: 30,
  stormShieldStrength: 0,
  plantGrowth: 0,
  plantWatered: false,
  plantLightOn: false,
  phase: "intro" as Phase,
  timeOfDay: "Evening" as TimeOfDay,
  modal: null as Modal,
  assistantText: "",
  tasks: INITIAL_TASKS.map((t) => ({ ...t })),
  activeTaskId: "connect-battery" as TaskId | null,
  quizAnswer: null as QuizAnswer,
  quizRetries: 0,
  quizDone: false,
  score: 0,
  badges: [] as Badge[],
  donkiSource: "",
  donkiMessage: "",
};

function updateTasks(tasks: MissionTask[], doneId: TaskId, nextId?: TaskId): MissionTask[] {
  return tasks.map((t) => {
    if (t.id === doneId) return { ...t, state: "done" };
    if (t.id === nextId) return { ...t, state: "active" };
    return t;
  });
}

export const useGame = create<GameState>((set, get) => ({
  ...INITIAL,

  setPhase: (p) => set({ phase: p }),
  setTimeOfDay: (t) => set({ timeOfDay: t }),
  openModal: (m) => set({ modal: m }),
  closeModal: () => set({ modal: null }),
  setAssistant: (t) => set({ assistantText: t }),
  setBattery: (n) => set((s) => ({ battery: Math.max(0, Math.min(s.batteryMax, n)) })),

  connectBase: () => {
    const s = get();
    if (s.baseConnected) return;
    set({
      baseConnected: true,
      baseStatus: s.battery >= 4 ? "ready" : "low-power",
      modal: null,
      score: s.score + 100,
      assistantText: "Power cable connected! The base will draw electricity from the battery after sunset.",
      tasks: updateTasks(s.tasks, "connect-battery", "plan-rover"),
      activeTaskId: "plan-rover",
    });
  },

  chargeRobotNow: () => {
    const s = get();
    if (s.robotStatus !== "uncharged") return;
    const newBattery = Math.max(0, s.battery - 2);
    set({
      battery: newBattery,
      robotStatus: "charged",
      baseStatus: newBattery >= 4 ? "ready" : "low-power",
      modal: null,
      score: s.score + 50,
      assistantText: "Rover charged! The battery dropped to 2 — not enough for the night. Tap the solar panels to top up before sunset.",
      tasks: updateTasks(s.tasks, "plan-rover", "top-up"),
      activeTaskId: "top-up",
    });
  },

  chargeRobotMorning: () => {
    const s = get();
    if (s.robotStatus !== "uncharged") return;
    set({
      robotStatus: "charge-in-morning",
      modal: null,
      score: s.score + 50,
      assistantText: "Good plan — keep the reserve for the base. The rover will charge in the morning. Ready to check the plan.",
      tasks: s.tasks.map((t) =>
        t.id === "plan-rover" ? { ...t, state: "done" }
        : t.id === "top-up" ? { ...t, state: "skipped" }
        : t.id === "check-plan" ? { ...t, state: "active" }
        : t
      ),
      activeTaskId: "check-plan",
    });
  },

  waitSunset: () => {
    const s = get();
    if (s.eveningRefillUsed) return;
    set({
      eveningRefillUsed: true,
      phase: "sunset-wait",
      timeOfDay: "Sunset",
      modal: null,
      assistantText: "Waiting for sunset… the solar panels collect the last energy.",
    });
    setTimeout(() => {
      const st = get();
      const target = st.robotStatus === "charge-in-morning" ? 6 : 4;
      set({
        battery: target,
        phase: "evening",
        baseStatus: "ready",
        score: st.score + 75,
        assistantText:
          target === 6
            ? "Sunset. Battery is full (6/6). The rover will charge in the morning."
            : "Sunset. Battery is back to 4/6 — just enough for the night, rover is ready too.",
        tasks: updateTasks(st.tasks, "top-up", "check-plan"),
        activeTaskId: "check-plan",
      });
    }, 2600);
  },

  startPlanCheck: () => set({ phase: "plan-check", modal: "plan" }),

  beginNight: () => {
    set({
      phase: "night",
      modal: null,
      timeOfDay: "Night",
      nightStage: 0,
      nightEnergyUsed: 0,
      nightPaused: false,
      assistantText: "Night falls. The battery powers the base while the crew rests.",
      tasks: updateTasks(get().tasks, "check-plan", "survive-night"),
      activeTaskId: "survive-night",
    });
  },

  advanceNight: () => {
    const s = get();
    if (s.nightPaused) return;
    if (s.nightStage >= 4) return;
    const next = s.nightStage + 1;
    const newBattery = Math.max(0, s.battery - 1);
    const triggerStorm = next === 3 && s.stormEvent && !s.stormResolved;
    set({ nightStage: next, battery: newBattery, nightEnergyUsed: s.nightEnergyUsed + 1 });
    if (triggerStorm) {
      // start the storm countdown from the real NASA event's hoursToImpact (scaled to seconds)
      const cd = s.stormEvent?.hoursToImpact ? Math.max(12, Math.min(40, s.stormEvent.hoursToImpact * 2)) : 25;
      set({
        phase: "storm-decision",
        modal: "storm",
        stormCountdown: cd,
        tasks: updateTasks(get().tasks, "survive-night", "handle-storm"),
        activeTaskId: "handle-storm",
      });
    } else if (next >= 4) {
      const tasks = s.stormResolved
        ? get().tasks
        : get().tasks.map((t) =>
            t.id === "survive-night" ? { ...t, state: "done" }
            : t.id === "handle-storm" ? { ...t, state: "skipped" }
            : t
          );
      set({
        phase: "dawn",
        timeOfDay: "Dawn",
        tasks,
        activeTaskId: s.plantGrowth > 0 ? "complete" : "grow-plants",
      });
    }
  },

  toggleNightPause: () => set((s) => ({ nightPaused: !s.nightPaused })),

  setStormEvent: (e) => set({ stormEvent: e }),

  tickStorm: () => {
    const s = get();
    if (s.phase !== "storm-decision" || s.stormCountdown <= 0) return;
    const nc = s.stormCountdown - 1;
    set({ stormCountdown: nc });
    if (nc <= 0 && !s.stormResolved) {
      // storm hits — resolve automatically if the player hasn't decided
      get().resolveStorm(s.stormShieldStrength > 0 ? "shelter" : "ignore");
    }
  },

  buildShield: (amount) => {
    const s = get();
    if (s.phase !== "storm-decision") return;
    set({
      stormShieldStrength: Math.min(100, s.stormShieldStrength + amount),
      score: s.score + 5,
    });
  },

  resolveStorm: (choice) => {
    const s = get();
    // Real NASA logic: storm intensity (0..100) drives radiation dose.
    // Sheltering with ~10 g/cm² water shield (NASA-STD-3001) cuts dose sharply.
    const intensity = s.stormEvent?.intensity ?? 50;
    const shield = s.stormShieldStrength;
    const protected_ = choice === "shelter";
    // Base dose bump from storm (intensity ~ mSv extra over the night)
    const stormDose = (intensity / 100) * 2.5;
    // Shielding cuts it up to ~80% if fully built
    const reduction = protected_ ? Math.min(0.8, (shield / 100) * 0.85) : 0;
    const finalDose = stormDose * (1 - reduction);
    const newRad = s.radiationLevel + finalDose;
    const scoreBonus = protected_ ? Math.round(150 + shield * 1.5) : 40;
    set({
      stormChoice: choice,
      stormResolved: true,
      modal: null,
      phase: "night",
      radiationLevel: Math.min(8, newRad),
      score: s.score + scoreBonus,
      badges: protected_ && shield >= 80 ? Array.from(new Set([...s.badges, "shelter-pro" as Badge])) : s.badges,
      assistantText: protected_
        ? `Crew sheltered! Your water shield blocked ${Math.round(reduction * 100)}% of the storm's radiation. NASA-STD-3001 approves!`
        : "Crew stayed outside the shelter. Radiation exposure this night was much higher.",
      tasks: updateTasks(get().tasks, "handle-storm", "survive-night"),
      activeTaskId: "survive-night",
    });
  },

  waterPlant: () => {
    const s = get();
    if (s.plantWatered) return;
    set({ plantWatered: true, score: s.score + 20 });
  },

  togglePlantLight: () => {
    const s = get();
    set({ plantLightOn: !s.plantLightOn, score: s.score + (s.plantLightOn ? 0 : 20) });
  },

  growPlantTick: () => {
    const s = get();
    if (!s.plantWatered || !s.plantLightOn) return;
    if (s.plantGrowth >= 100) return;
    const next = Math.min(100, s.plantGrowth + 8);
    const justDone = next >= 100 && s.plantGrowth < 100;
    set({ plantGrowth: next });
    if (justDone) {
      set({
        score: get().score + 100,
        badges: Array.from(new Set([...get().badges, "green-thumb" as Badge])),
        tasks: get().tasks.map((t) =>
          t.id === "grow-plants" ? { ...t, state: "done" } : t
        ),
        activeTaskId: "complete",
        assistantText: "Your plants are fully grown! Just like NASA's plant experiments on the ISS.",
      });
    }
  },

  submitQuiz: (a) => {
    const s = get();
    if (a === "battery") {
      set({
        quizAnswer: a,
        quizDone: true,
        score: s.score + 200,
        badges: Array.from(new Set([...s.badges, "first-night" as Badge])),
        assistantText: "Correct! The battery stored the electricity collected earlier — that's what kept the base running after sunset.",
        tasks: updateTasks(get().tasks, "complete"),
        activeTaskId: null,
      });
    } else {
      set({
        quizAnswer: a,
        quizRetries: s.quizRetries + 1,
        assistantText: "Not quite. Follow the power path at night: it comes from the battery, not the panels. Try again!",
      });
    }
  },

  restart: () =>
    set({
      ...INITIAL,
      phase: "evening",
      timeOfDay: "Evening",
      tasks: INITIAL_TASKS.map((t) => ({ ...t })),
      activeTaskId: "connect-battery",
    }),

  initFromDonki: ({ source, message, events }) => {
    const pick =
      events.find((e) => e.kind === "CME") ??
      events.find((e) => e.classType?.startsWith("X")) ??
      events.find((e) => e.classType?.startsWith("M")) ??
      events[0];
    if (!pick) return;
    set({ donkiSource: source, donkiMessage: message, stormEvent: { ...pick, source } });
  },
}));
